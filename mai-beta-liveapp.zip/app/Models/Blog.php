<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $fillable = [
        'title',
        'slug',
        'content',
        'author_id',
        'published_at',
        'status',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'featured_image',
        'views',
    ];

    /**
     * Relationship with User (author).
     */
    public function author()
    {
        return $this->belongsTo(User::class, 'author_id');
    }
}
